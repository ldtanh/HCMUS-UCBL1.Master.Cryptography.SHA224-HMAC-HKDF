This code is implemented with Python 3.

Just run `python sha224_hmac_hkdf.py` and follow the instruction.